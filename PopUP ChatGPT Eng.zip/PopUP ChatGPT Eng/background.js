let popupWindowId = null;
let popupTabId = null;

const defaultPrompt = '{selectedWord}\n{sentence}\nExplain the meaning of the word and its grammatical role in this context.';
const defaultPromptRemoveWord = '{sentence}\nExplain the grammar and meaning of the sentence.';
const defaultPromptRemoveSentence = '{selectedWord}\nDescribe what this word means and how it is used.';
const defaultPromptExplainSentence = '{selectedWord}\n{sentence}\nCustom prompt';
const defaultPromptExplainText = '{selectedWord}\nAnalyze the text: explain its meaning and grammatical features.';

function buildPrompt(selectedWord, sentence, settings = {}, checkboxes = {}) {
  const removeWord = checkboxes.removeWord;
  const removeSentence = checkboxes.removeSentence;
  const explainSentence = checkboxes.explainSentence;
  const explainText = checkboxes.explainText;

  let template = '';

  if (removeWord && removeSentence) {
    return '';
  } else if (explainText && settings.promptExplainText) {
    template = settings.promptExplainText;
  } else if (explainSentence && settings.promptExplainSentence) {
    template = settings.promptExplainSentence;
  } else if (removeWord && settings.promptRemoveWord) {
    template = settings.promptRemoveWord;
  } else if (removeSentence && settings.promptRemoveSentence) {
    template = settings.promptRemoveSentence;
  } else {
    template = settings.customPrompt || defaultPrompt;
  }

  template = template.replace(/\{selectedWord\}/g, selectedWord || '');
  template = template.replace(/\{sentence\}/g, sentence || '');

  return template.trim();
}

function copyToClipboard(tabId, text) {
  chrome.scripting.executeScript({
    target: { tabId },
    func: (text) => {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
    },
    args: [text]
  }, () => {
    if (chrome.runtime.lastError) {
      chrome.notifications.create({
        type: 'basic',
        title: 'Error',
        message: 'Error copying text.'
      });
    }
  });
}

function insertAndSendText(tabId, text, callback) {
  chrome.scripting.executeScript({
    target: { tabId },
    func: (text) => {
      function waitAndInsert(retries = 30) {
        const loginFields = document.querySelector('input[name="username"], input[type="password"]');
        if (loginFields) return { error: 'Authorization required for ChatGPT.' };

        const selectors = [
          'textarea',
          'textarea[data-testid="chat-input"]',
          'textarea#prompt-textarea',
          '[contenteditable="true"]'
        ];
        const input = selectors.map(s => document.querySelector(s)).find(Boolean);
        if (!input) {
          if (retries <= 0) return { error: 'Input field not found.' };
          setTimeout(() => waitAndInsert(retries - 1), 500);
          return;
        }

        input.focus();
        input.value = '';
        document.execCommand('insertText', false, text);
        input.dispatchEvent(new InputEvent('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));

        const sendButton = document.querySelector('button[data-testid="send-button"]') ||
          Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('➤'));

        if (sendButton) {
          setTimeout(() => sendButton.click(), 500);
        } else {
          input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        }

        return { success: true };
      }
      return waitAndInsert();
    },
    args: [text]
  }, (results) => {
    if (chrome.runtime.lastError) {
      chrome.notifications.create({
        type: 'basic',
        title: 'Error',
        message: 'Error inserting text: ' + chrome.runtime.lastError.message
      });
    } else if (results?.[0]?.result?.error) {
      chrome.notifications.create({
        type: 'basic',
        title: 'Error',
        message: results[0].result.error
      });
    }
    if (callback) callback();
  });
}

function openOrReusePopupWithText(text) {
  chrome.tabs.query({}, (tabs) => {
    const existingTab = tabs.find(tab =>
      tab.url && tab.url.startsWith('https://chatgpt.com/c/')
    );

    if (existingTab) {
      popupTabId = existingTab.id;
      popupWindowId = existingTab.windowId;

      chrome.windows.update(popupWindowId, { focused: true }, () => {
        chrome.tabs.update(popupTabId, { active: true }, () => {
          insertAndSendText(popupTabId, text);
        });
      });
    } else {
      createNewPopupWindow(text);
    }
  });
}

function createNewPopupWindow(text) {
  chrome.windows.create({
    url: 'https://chatgpt.com/',
    type: 'popup',
    width: 800,
    height: 600,
    left: 100,
    top: 100
  }, (newWindow) => {
    if (!newWindow || !newWindow.tabs?.[0]) {
      chrome.notifications.create({
        type: 'basic',
        title: 'Error',
        message: 'Failed to open ChatGPT window.'
      });
      return;
    }

    popupWindowId = newWindow.id;
    popupTabId = newWindow.tabs[0].id;

    chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
      if (tabId === popupTabId && changeInfo.status === 'complete') {
        insertAndSendText(tabId, text);
        chrome.tabs.onUpdated.removeListener(listener);
      }
    });
  });
}

function handleSelectedWord(tabId, selectedWord) {
  chrome.scripting.executeScript({
    target: { tabId },
    args: [selectedWord],
    func: (word) => {
      const selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) return { error: 'Unable to retrieve selection.' };

      let container = selection.getRangeAt(0).commonAncestorContainer;
      while (container && container.nodeType !== 1) {
        container = container.parentNode;
      }

      let fullText = '';
      let attempts = 0;
      while (container && attempts < 5) {
        fullText = container.innerText || container.textContent || '';
        if (fullText.includes(word) && fullText.length > 10) break;
        container = container.parentNode;
        attempts++;
      }

      if (fullText) {
        let splitByPunct = fullText.split(/(?<=[。！？.!?])/);
        let sentences = [];
        splitByPunct.forEach(part => {
          if (part.length > 100) {
            sentences.push(...part.split('\u3000'));
          } else {
            sentences.push(part);
          }
        });

        for (const sentence of sentences) {
          if (sentence.includes(word)) return { sentence: sentence.trim() };
        }
      }

      return { sentence: fullText || word };
    }
  }, (results) => {
    if (chrome.runtime.lastError || !results?.[0]?.result) {
      chrome.notifications.create({
        type: 'basic',
        title: 'Error',
        message: 'Unable to find sentence.'
      });
      return;
    }

    const result = results[0].result;
    if (result.error) {
      chrome.notifications.create({
        type: 'basic',
        title: 'Error',
        message: result.error
      });
      return;
    }

    const sentence = result.sentence || selectedWord;

    chrome.storage.sync.get([
      'customPrompt',
      'checkboxStates',
      'promptRemoveWord',
      'promptRemoveSentence',
      'promptExplainSentence',
      'promptExplainText'
    ], (data) => {
      const prompt = buildPrompt(selectedWord, sentence, {
        customPrompt: data.customPrompt,
        promptRemoveWord: data.promptRemoveWord,
        promptRemoveSentence: data.promptRemoveSentence,
        promptExplainSentence: data.promptExplainSentence || defaultPromptExplainSentence,
        promptExplainText: data.promptExplainText || defaultPromptExplainText
      }, data.checkboxStates || {});

      copyToClipboard(tabId, prompt);
      openOrReusePopupWithText(prompt);
    });
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get([
    'customPrompt',
    'checkboxStates',
    'showFloatingBtn',
    'promptRemoveWord',
    'promptRemoveSentence',
    'promptExplainSentence',
    'promptExplainText'
  ], (data) => {
    if (
      data.customPrompt === undefined ||
      data.checkboxStates === undefined ||
      data.showFloatingBtn === undefined ||
      data.promptRemoveWord === undefined ||
      data.promptRemoveSentence === undefined ||
      data.promptExplainSentence === undefined ||
      data.promptExplainText === undefined
    ) {
      chrome.storage.sync.set({
        customPrompt: defaultPrompt,
        checkboxStates: { removeSentence: false, removeWord: false, explainSentence: false, explainText: false },
        showFloatingBtn: true,
        promptRemoveWord: defaultPromptRemoveWord,
        promptRemoveSentence: defaultPromptRemoveSentence,
        promptExplainSentence: defaultPromptExplainSentence,
        promptExplainText: defaultPromptExplainText
      });
    }
  });

  chrome.contextMenus.create({
    id: "copySelectedWordAndSentence",
    title: "Analyze word with ChatGPT",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "copySelectedWordAndSentence" || !tab?.id) return;
  const selectedWord = info.selectionText?.trim();
  if (!selectedWord) {
    chrome.notifications.create({
      type: 'basic',
      title: 'Error',
      message: 'No word selected.'
    });
    return;
  }
  handleSelectedWord(tab.id, selectedWord);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'selectedText') {
    const selectedWord = message.text?.trim();
    const sentence = message.sentence?.trim();

    if (!selectedWord) {
      sendResponse({ error: 'No selected text' });
      return;
    }

    chrome.storage.sync.get([
      'customPrompt',
      'checkboxStates',
      'promptRemoveWord',
      'promptRemoveSentence',
      'promptExplainSentence',
      'promptExplainText'
    ], (data) => {
      const prompt = buildPrompt(selectedWord, sentence, {
        customPrompt: data.customPrompt,
        promptRemoveWord: data.promptRemoveWord,
        promptRemoveSentence: data.promptRemoveSentence,
        promptExplainSentence: data.promptExplainSentence || defaultPromptExplainSentence,
        promptExplainText: data.promptExplainText || defaultPromptExplainText
      }, data.checkboxStates || {});

      if (sender.tab?.id) {
        copyToClipboard(sender.tab.id, prompt);
        openOrReusePopupWithText(prompt);
      }
      sendResponse({ prompt });
    });

    return true;
  }
});

chrome.windows.onRemoved.addListener(windowId => {
  if (windowId === popupWindowId) {
    popupWindowId = null;
    popupTabId = null;
  }
});