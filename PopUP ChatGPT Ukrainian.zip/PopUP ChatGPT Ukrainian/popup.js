const promptTextarea = document.getElementById('prompt');
const promptRemoveWordTextarea = document.getElementById('promptRemoveWord');
const promptRemoveSentenceTextarea = document.getElementById('promptRemoveSentence');
const promptExplainSentenceTextarea = document.getElementById('promptExplainSentence');
const promptExplainTextTextarea = document.getElementById('promptExplainText');

const explainSentenceCheckbox = document.getElementById('explainSentence');
const removeSentenceCheckbox = document.getElementById('removeSentence');
const removeWordCheckbox = document.getElementById('removeWord');
const explainTextCheckbox = document.getElementById('explainText');
const showFloatingBtnCheckbox = document.getElementById('showFloatingBtn');

const saveBtn = document.getElementById('saveBtn');
const resetBtn = document.getElementById('resetBtn');
const statusDiv = document.getElementById('status');

const STORAGE_KEY = 'customPrompt';
const CHECKBOX_KEY = 'checkboxStates';
const FLOATING_BTN_KEY = 'showFloatingBtn';
const PROMPT_REMOVE_WORD_KEY = 'promptRemoveWord';
const PROMPT_REMOVE_SENTENCE_KEY = 'promptRemoveSentence';
const PROMPT_EXPLAIN_SENTENCE_KEY = 'promptExplainSentence';
const PROMPT_EXPLAIN_TEXT_KEY = 'promptExplainText';

const defaultPrompt = '{selectedWord}\n{sentence}\nПоясни значення слова та його граматичну роль у цьому контексті.';
const defaultPromptRemoveWord = '{sentence}\nПоясни граматику та сенс речення.';
const defaultPromptRemoveSentence = '{selectedWord}\nРозкажи, що означає це слово та як воно використовується.';
const defaultPromptExplainSentence = '{selectedWord}\n{sentence}\nКастомний промпт';
const defaultPromptExplainText = '{selectedWord}\nПроаналізуй текст: поясни його сенс і граматичні особливості.';

function setFields(data) {
  promptTextarea.value = data[STORAGE_KEY] || defaultPrompt;
  promptRemoveWordTextarea.value = data[PROMPT_REMOVE_WORD_KEY] || defaultPromptRemoveWord;
  promptRemoveSentenceTextarea.value = data[PROMPT_REMOVE_SENTENCE_KEY] || defaultPromptRemoveSentence;
  promptExplainSentenceTextarea.value = data[PROMPT_EXPLAIN_SENTENCE_KEY] || defaultPromptExplainSentence;
  promptExplainTextTextarea.value = data[PROMPT_EXPLAIN_TEXT_KEY] || defaultPromptExplainText;

  const checkboxStates = data[CHECKBOX_KEY] || {};
  removeSentenceCheckbox.checked = checkboxStates.removeSentence || false;
  removeWordCheckbox.checked = checkboxStates.removeWord || false;
  explainSentenceCheckbox.checked = checkboxStates.explainSentence || false;
  explainTextCheckbox.checked = checkboxStates.explainText || false;
  showFloatingBtnCheckbox.checked = data[FLOATING_BTN_KEY] !== false;
}

function loadSettings() {
  setFields({
    [STORAGE_KEY]: defaultPrompt,
    [CHECKBOX_KEY]: { removeSentence: false, removeWord: false, explainSentence: false, explainText: false },
    [FLOATING_BTN_KEY]: true,
    [PROMPT_REMOVE_WORD_KEY]: defaultPromptRemoveWord,
    [PROMPT_REMOVE_SENTENCE_KEY]: defaultPromptRemoveSentence,
    [PROMPT_EXPLAIN_SENTENCE_KEY]: defaultPromptExplainSentence,
    [PROMPT_EXPLAIN_TEXT_KEY]: defaultPromptExplainText
  });

  chrome.storage.sync.get([
    STORAGE_KEY,
    CHECKBOX_KEY,
    FLOATING_BTN_KEY,
    PROMPT_REMOVE_WORD_KEY,
    PROMPT_REMOVE_SENTENCE_KEY,
    PROMPT_EXPLAIN_SENTENCE_KEY,
    PROMPT_EXPLAIN_TEXT_KEY
  ], (data) => {
    if (
      data[STORAGE_KEY] !== undefined &&
      data[CHECKBOX_KEY] !== undefined &&
      data[FLOATING_BTN_KEY] !== undefined &&
      data[PROMPT_REMOVE_WORD_KEY] !== undefined &&
      data[PROMPT_REMOVE_SENTENCE_KEY] !== undefined &&
      data[PROMPT_EXPLAIN_SENTENCE_KEY] !== undefined &&
      data[PROMPT_EXPLAIN_TEXT_KEY] !== undefined
    ) {
      setFields(data);
    } else {
      chrome.storage.sync.set({
        [STORAGE_KEY]: defaultPrompt,
        [CHECKBOX_KEY]: { removeSentence: false, removeWord: false, explainSentence: false, explainText: false },
        [FLOATING_BTN_KEY]: true,
        [PROMPT_REMOVE_WORD_KEY]: defaultPromptRemoveWord,
        [PROMPT_REMOVE_SENTENCE_KEY]: defaultPromptRemoveSentence,
        [PROMPT_EXPLAIN_SENTENCE_KEY]: defaultPromptExplainSentence,
        [PROMPT_EXPLAIN_TEXT_KEY]: defaultPromptExplainText
      });
    }
  });
}

function saveSettings() {
  const promptText = promptTextarea.value.trim();
  const promptRemoveWord = promptRemoveWordTextarea.value.trim();
  const promptRemoveSentence = promptRemoveSentenceTextarea.value.trim();
  const promptExplainSentence = promptExplainSentenceTextarea.value.trim();
  const promptExplainText = promptExplainTextTextarea.value.trim();

  const checkboxStates = {
    removeSentence: removeSentenceCheckbox.checked,
    removeWord: removeWordCheckbox.checked,
    explainSentence: explainSentenceCheckbox.checked,
    explainText: explainTextCheckbox.checked
  };

  const showFloatingBtn = showFloatingBtnCheckbox.checked;

  chrome.storage.sync.set({
    [STORAGE_KEY]: promptText,
    [CHECKBOX_KEY]: checkboxStates,
    [FLOATING_BTN_KEY]: showFloatingBtn,
    [PROMPT_REMOVE_WORD_KEY]: promptRemoveWord,
    [PROMPT_REMOVE_SENTENCE_KEY]: promptRemoveSentence,
    [PROMPT_EXPLAIN_SENTENCE_KEY]: promptExplainSentence,
    [PROMPT_EXPLAIN_TEXT_KEY]: promptExplainText
  }, () => {
    statusDiv.textContent = 'Збережено!';
    setTimeout(() => (statusDiv.textContent = ''), 1500);

    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (tab.url && tab.url.startsWith('http')) {
          chrome.tabs.sendMessage(tab.id, {
            action: 'updateShowFloatingBtn',
            show: showFloatingBtn
          }, () => {});
        }
      }
    });
  });
}

function resetSettings() {
  setFields({
    [STORAGE_KEY]: defaultPrompt,
    [CHECKBOX_KEY]: { removeSentence: false, removeWord: false, explainSentence: false, explainText: false },
    [FLOATING_BTN_KEY]: true,
    [PROMPT_REMOVE_WORD_KEY]: defaultPromptRemoveWord,
    [PROMPT_REMOVE_SENTENCE_KEY]: defaultPromptRemoveSentence,
    [PROMPT_EXPLAIN_SENTENCE_KEY]: defaultPromptExplainSentence,
    [PROMPT_EXPLAIN_TEXT_KEY]: defaultPromptExplainText
  });

  chrome.storage.sync.set({
    [STORAGE_KEY]: defaultPrompt,
    [CHECKBOX_KEY]: { removeSentence: false, removeWord: false, explainSentence: false, explainText: false },
    [FLOATING_BTN_KEY]: true,
    [PROMPT_REMOVE_WORD_KEY]: defaultPromptRemoveWord,
    [PROMPT_REMOVE_SENTENCE_KEY]: defaultPromptRemoveSentence,
    [PROMPT_EXPLAIN_SENTENCE_KEY]: defaultPromptExplainSentence,
    [PROMPT_EXPLAIN_TEXT_KEY]: defaultPromptExplainText
  }, () => {
    statusDiv.textContent = 'Промпти скинуто!';
    setTimeout(() => (statusDiv.textContent = ''), 1500);
  });
}

removeSentenceCheckbox.addEventListener('change', () => {
  if (removeSentenceCheckbox.checked) {
    removeWordCheckbox.checked = false;
    explainSentenceCheckbox.checked = false;
    explainTextCheckbox.checked = false;
  }
});

removeWordCheckbox.addEventListener('change', () => {
  if (removeWordCheckbox.checked) {
    removeSentenceCheckbox.checked = false;
    explainSentenceCheckbox.checked = false;
    explainTextCheckbox.checked = false;
  }
});

explainSentenceCheckbox.addEventListener('change', () => {
  if (explainSentenceCheckbox.checked) {
    removeSentenceCheckbox.checked = false;
    removeWordCheckbox.checked = false;
    explainTextCheckbox.checked = false;
  }
});

explainTextCheckbox.addEventListener('change', () => {
  if (explainTextCheckbox.checked) {
    removeSentenceCheckbox.checked = false;
    removeWordCheckbox.checked = false;
    explainSentenceCheckbox.checked = false;
  }
});

saveBtn.addEventListener('click', saveSettings);
resetBtn.addEventListener('click', resetSettings);
window.addEventListener('load', loadSettings);

const promptPopup = document.getElementById('promptPopup');
const promptHeader = document.getElementById('togglePromptsBtn');
promptHeader.addEventListener('click', () => {
  promptPopup.classList.toggle('open');
});